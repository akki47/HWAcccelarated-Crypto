#pragma once

#define __attribute__(X)
#define inline
#define __func__ __FUNCTION__

#define NULL 0

#define snprintf _snprintf